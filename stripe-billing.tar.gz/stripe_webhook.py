from fastapi import FastAPI, Request, HTTPException
import stripe
import os
import logging
from core_ref.services.wallet import WalletService
from core_ref.gateway.db import SessionLocal
from datetime import datetime

logger = logging.getLogger("stripe_webhook")
logger.setLevel(logging.INFO)

app = FastAPI()

STRIPE_SECRET = os.getenv("STRIPE_SECRET")
STRIPE_WEBHOOK_SECRET = os.getenv("STRIPE_WEBHOOK_SECRET")

@app.post("/")
async def stripe_webhook(request: Request):
    payload = await request.body()
    sig_header = request.headers.get("stripe-signature")
    try:
        event = stripe.Webhook.construct_event(
            payload, sig_header, STRIPE_WEBHOOK_SECRET
        )
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Invalid signature: {e}")

    if event["type"] == "payment_intent.succeeded":
        data = event["data"]["object"]
        user_id = data.get("metadata", {}).get("user_id", "anonymous")
        amount_eur = data["amount_received"] / 100
        cbt_amount = round(amount_eur * 100, 2)

        db = SessionLocal()
        try:
            wallet = WalletService(db)
            wallet.record_event(
                user_id=user_id,
                delta=cbt_amount,
                event_type="top_up",
                metadata={
                    "payment_intent_id": data.get("id"),
                    "amount_eur": amount_eur,
                    "created_at": datetime.utcnow().isoformat(),
                },
                token="cT",
                reason="Stripe top-up"
            )
            logger.info(f"Top-up recorded for user {user_id}: {cbt_amount} cT ({amount_eur}€)")
        finally:
            db.close()

    return {"status": "ok", "received": True}
